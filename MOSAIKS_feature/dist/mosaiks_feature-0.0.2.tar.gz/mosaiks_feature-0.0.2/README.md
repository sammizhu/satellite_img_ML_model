tests ran just going to tests/ and then runing pytest. check to ensure environment var
set to right path if running into issues 