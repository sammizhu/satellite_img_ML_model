## Purpose of Package ##
This is a Python Library generated to replicate the steps done by the research in `Program Evaluation with Remotely Sensed Outcomes` by Ashesh Rambachan, Rahul Singh, and Davide Viviano†. 

### NOTE: Before running code, make sure to install the libraries and versions required in `requirements.txt`

## Package Overview ##
```
├── src/MOSAIKS_feature/
    ├── analysis/
    │   ├── __init__.py
    │   ├── img_generation_heatmap.py   
    |   ├── Satellite_Image_Generation and Mosaiks_Heat_Map-Documentation_Final.md
    ├── extract_features/
    │   ├── __init__.py
    │   ├── aggregate_features.py
    │   ├── granular_coords.py
    │   ├── strategy_two.py
    ├── testing/
    │   ├── __init__.py
    │   ├── aggregate_features_functional.py
    │   ├── granular_coords_functional.py
    │   ├── strategy_two_functional.py   
    ├── __init__.py
    ├── misc.py
    ├── requirements.txt
├── tests/
```
### Analysis
`img_generation_heatmap.py`: Processes, analyzes, and visualizes Mosaik data and SHRID level Satellite images
`Satellite_Image_Generation and Mosaiks_Heat_Map-Documentation_Final.md`: Documentation for how analysis pipeline

### Extract Features
`aggregate_features_functional.py`: 
- Purpose: This script averages the MOSAIKS feature data for each coordinate to create a summarized dataset
- Steps:
    - Run aggregate_features.py on the downloaded MOSAIKS result files
    - The script will compute the average of each feature across the files for each coordinate
- Output: A final CSV file with the averaged features for each coordinate point, ready for further analysis

`granular_coords_functional.py`: 
- Purpose: This script processes a CSV of polygon coordinates, breaking down each polygon into more granular coordinate points
- Steps:
    - Run v3.py on the original CSV of polygon coordinates
    - The script will divide the coordinates into multiple output files, each containing no more than 100,000 rows, to meet the MOSAIKS input limitation
- Output: Several CSV files with a maximum of 100,000 rows each, containing the granular versions of the polygon coordinates

`strategy_two_functional.py`:
- Purpose: This method simplifies feature extraction by using the centroid (central longitude and latitude) of each polygon rather than a granular breakdown, addressing the requirement to get one set of features per grid.
- Steps:
    - Prepare a CSV file containing the centroid longitude and latitude for each polygon.
    - Upload the centroid CSV file into the MOSAIKS file query system.
    - Execute the query to gather features for the centroid of each polygon.
    - Download the resulting feature files from MOSAIKS once the query completes.
- Output: A MOSAIKS result file containing features for the centroid coordinates of each polygon.

### `misc.py`: 
- Various python functions for additional csv functionalities such as removing duplicates, merging files, counting distinct rows, and grabing a subset of a csv

### tests/
- Test files for aggregate_features_functional.py, granular_coords_functional.py, and strategy_two_functional.py

### Testing
These code files replicate the functionality of those in the `Extract Features` directory, but have been refactored into more modular, function-based components. This approach enables testing within a separate tests folder, external to the MOSAIKS_features directory.

## Replication Steps ##
